import { eq } from "drizzle-orm";
import db from "../config/db.js";
import { users, merchants } from "../models/schema.js";
import logger from "../utils/logger.js";
import { generateOTP, sendOTPEmail } from "../utils/emailService.js";
import bcrypt from "bcryptjs";
import jwt from "jsonwebtoken";

const JWT_SECRET = process.env.JWT_SECRET || "nidhi_super_secret_key_2026";
const JWT_EXPIRES_IN = "7d";

// ─── BECOME A MERCHANT ──────────────────────────────────────
export const registerMerchant = async (req, res) => {
    try {
        const userId = req.user.id; // From authenticateToken middleware
        const { businessName, businessType, description } = req.body;

        if (!businessName) {
            return res.status(400).json({ success: false, message: "Business name is required" });
        }

        // Check if user is already a merchant
        const existingMerchant = await db
            .select()
            .from(merchants)
            .where(eq(merchants.userId, userId));

        if (existingMerchant.length > 0) {
            return res.status(400).json({ success: false, message: "User is already a merchant" });
        }

        // Create merchant profile
        const newMerchant = await db
            .insert(merchants)
            .values({
                userId,
                businessName,
                businessType: businessType || "retail",
                description,
                status: "active",
            })
            .returning();

        logger.info(`User ${userId} upgraded to merchant: ${businessName}`);

        return res.status(201).json({
            success: true,
            message: "Merchant account created successfully!",
            data: newMerchant[0],
        });
    } catch (error) {
        logger.error(`Merchant registration error: ${error.message}`);
        return res.status(500).json({ success: false, message: "Internal server error" });
    }
};

// ─── GET MERCHANT PROFILE ───────────────────────────────────
export const getMerchantProfile = async (req, res) => {
    try {
        const userId = req.user.id;

        // Join merchants with users to get full profile
        const result = await db
            .select({
                id: merchants.id,
                businessName: merchants.businessName,
                businessType: merchants.businessType,
                description: merchants.description,
                availableBalance: merchants.availableBalance,
                pendingBalance: merchants.pendingBalance,
                status: merchants.status,
                createdAt: merchants.createdAt,
                user: {
                    name: users.name,
                    email: users.email,
                }
            })
            .from(merchants)
            .innerJoin(users, eq(merchants.userId, users.id))
            .where(eq(merchants.userId, userId));

        if (result.length === 0) {
            // Return 200 with null data instead of 404 to avoid console errors
            return res.status(200).json({ success: true, data: null });
        }

        return res.status(200).json({ success: true, data: result[0] });
    } catch (error) {
        logger.error(`Get merchant profile error: ${error.message}`);
        return res.status(500).json({ success: false, message: "Internal server error" });
    }
};

// ─── MERCHANT LOGIN (Reuses Auth, but checks merchant status) ─
// Frontend should use standard /api/auth/login, then call /api/merchants/profile
// If profile 404s, redirect to /merchants/register
